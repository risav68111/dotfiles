#!/usr/bin/env bash

echo "before"
bash "/home/risav/.config/scripts/brightness.sh" 10
echo "after"
