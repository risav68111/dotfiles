#!/usr/bin/env bash

# Apps with visible windows
clients=$(hyprctl clients -j | jq -r '.[].class' 2>/dev/null | sort -u)

# Running processes
running=$(ps -e -o comm= | sort -u)

# Known GUI apps from .desktop
apps=$(grep -h '^Exec=' /usr/share/applications/*.desktop \
  | sed 's/^Exec=//' \
  | awk '{print $1}' \
  | xargs -I{} basename {} \
  | sort -u)

# Find: running GUI apps that are NOT in clients
comm -23 <(echo "$running" | grep -Fxf <(echo "$apps") | sort) \
         <(echo "$clients" | sort)
