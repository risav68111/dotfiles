#!/bin/bash

LOCK=/tmp/hyprshot.lock

if ! flock -n "$LOCK" true; then
    pid=$(lsof -t "$LOCK" 2>/dev/null)

    if [ -n "$pid" ]; then
        kill "$pid"
        sleep 0.1
    fi
fi

exec flock -n "$LOCK" hyprshot "$@"
# flock -n /tmp/hyprshot.lock hyprshot "$@" 

