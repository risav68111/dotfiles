#!/usr/bin/env bash

get_current() {
  if [ -f "$CACHE" ]; then
    cat "$CACHE"
  else
    ddcutil getvcp 10 | grep -oP 'current value = \K[0-9]+'
  fi
}
./brightness.sh $(get_current)
