#!/usr/bin/env bash

STEP=10
CACHE="/tmp/brightness_ddc"

get_current() {
  if [ -f "$CACHE" ]; then
    cat "$CACHE"
  else
    ddcutil getvcp 10 | grep -oP 'current value = \K[0-9]+'
  fi
}

set_value() {
  echo "$1" > "$CACHE"
  brightnessctl set "$1"%
  ddcutil setvcp 10 "$1" --sleep-multiplier=0.1
}

case "$1" in
  up)
    current=$(get_current)
    if [ $current -ge 100 ] ; then 
      exit 0 
    fi
    new=$((current + STEP))
    [ $new -gt 100 ] && new=100
    set_value "$new"
    ;;
  down)
    current=$(get_current)
    if [ $current -le 1 ] ; then 
      exit 0 
    fi
    new=$((current - STEP))
    [ $new -lt 0 ] && new=0
    set_value "$new"
    ;;
esac
