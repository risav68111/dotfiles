#!/usr/bin/env bash

case "$ROFI_RETV" in
    0)
        cliphist list
        ;;

    1)
        printf '%s\n' "$ROFI_INFO" | cliphist decode | wl-copy
        ;;

    2)
        printf '%s\n' "$ROFI_INFO" | cliphist delete
        echo "reload"
        ;;

    *)
        printf 'INVALID input: %s\n' "$ROFI_RETV" >&2
        ;;
esac
