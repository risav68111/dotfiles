import Quickshell
import QtQuick
import Quickshell.Wayland
import Quickshell.Io
import QtQuick.Layouts
import Quickshell.Hyprland

Rectangle {
    id: shellAppList
    color: "yellow"
    anchors.fill: parent
    Layout.fillWidth: true
    Layout.fillHeight: true
    radius: 30

    Item {
        id: appContainer
        property var apps: []
        Process {
            id: clientsProc
            command: ["hyprctl", "clients", "-j"]
            stdout: StdioCollector {
                onStreamFinished: {
                    try {
                        appContainer.apps = JSON.parse(text);
                        console.log("apps found:", appContainer.apps.length);
                    } catch (e) {
                        console.log("JSON error:", e);
                        console.log("output:", text);
                    }
                }
            }
        }

        Component.onCompleted: {
            clientsProc.running = true;
        }
        RowLayout {
            id: appsList
            anchors.fill: parent
            spacing: 0
            Repeater {
                model: appContainer.apps.length

                Rectangle {
                    required property int index

                    Layout.alignment: Qt.AlignVCenter
                    Layout.leftMargin: 2

                    Layout.minimumWidth: 28
                    Layout.preferredWidth: Math.min(Math.max(appTitle.implicitWidth + 40, 80), 200)
                    Layout.maximumWidth: 200

                    Layout.minimumHeight: 28
                    Layout.preferredHeight: 28

                    color: "#1a1b26"
                    opacity: 0.7
                    radius: 10

                    Row {
                        anchors.fill: parent
                        anchors.leftMargin: 6
                        anchors.rightMargin: 6
                        spacing: 6

                        Image {
                            width: 18
                            height: 18
                            anchors.verticalCenter: parent.verticalCenter

                            source: {
                                if (index >= appContainer.apps.length)
                                    return "";

                                const entry = DesktopEntries.heuristicLookup(appContainer.apps[index].class);

                                return entry && entry.icon ? Quickshell.iconPath(entry.icon) : "";
                            }

                            fillMode: Image.PreserveAspectFit
                        }

                        Text {
                            id: appTitle

                            anchors.verticalCenter: parent.verticalCenter

                            text: index < appContainer.apps.length ? appContainer.apps[index].initialTitle : ""

                            font.pixelSize: 15
                            color: "white"

                            elide: Text.ElideRight
                        }
                    }
                }
                Behavior on Layout.preferredWidth {
                    NumberAnimation {
                        duration: 150
                        easing.type: Easing.InOutQuad
                    }
                }
            }
        }
        // Text {
        //     text: appContainer.apps.length
        //     font.pixelSize: 18
        //     horizontalAlignment: Text.AlignHCenter
        //     verticalAlignment: Text.AlignVCenter
        // }
    }
}
